

text_1_article.addEventListener('mouseenter' , function(event){
    this.style.filter = 'drop-shadow(0px 0px 6px #fff)';
    this.style.transition = 'filter 3s'
})

text_1_article.addEventListener('mouseleave' ,function(event){
    this.style.filter = 'none';
    this.style.transition = 'filter 3s'
})

text_2_article.addEventListener('mouseenter' , function(event){
    this.style.filter = 'drop-shadow(0px 0px 6px #fff)';
    this.style.transition = 'filter 3s'
})

text_2_article.addEventListener('mouseleave' ,function(event){
    this.style.filter = 'none';
    this.style.transition = 'filter 3s'
})